package groomingSalon;

import java.util.ArrayList;
import java.util.List;

public class GroomingSalon {
    private int capacity;
    private List<Pet> data;

    public GroomingSalon(int capacity) {
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public void add(Pet pet) {
        if(this.data.size() < capacity) {
            this.data.add(pet);
        }
    }
    public boolean remove(String name) {
        for (Pet datum : data) {
            if(datum.getName().equals(name)) {
                this.data.remove(datum);
                return true;
            }
        }
        return false;
    }
    public Pet getPet(String name, String owner) {
        for (Pet datum : data) {
            if(datum.getName().equals(name) && datum.getOwner().equals(owner)) {
                return datum;
            }
        }
        return null;
    }
    public int getCount() {
        return data.size();
    }
    public String getStatistics() {
        StringBuilder builder = new StringBuilder();
        builder.append("The grooming salon has the following clients:").append(System.lineSeparator());
        for (Pet datum : data) {
            builder.append(datum.getName()).append(" ").append(datum.getOwner()).append(System.lineSeparator());
        }
        return builder.toString().trim();
    }
}
